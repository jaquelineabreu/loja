<?php
/* Smarty version 3.1.36, created on 2020-12-23 01:46:54
  from 'C:\wamp64\www\loja\view\produtos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5fe2a18ee18c94_46045267',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72230a973d9ab6ce4c238833840568d6ed74b3e7' => 
    array (
      0 => 'C:\\wamp64\\www\\loja\\view\\produtos.tpl',
      1 => 1608687996,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fe2a18ee18c94_46045267 (Smarty_Internal_Template $_smarty_tpl) {
?><h3>Lista de Produtos</h3>
<hr>

<section id="paginacao" class="row">
  <center>
    Paginas
  </center>
</section>


<section id="produtos" class="row">

  <ul style="list-style>:none">
    <div class="row" id="pularlinha">
      <!--Pega o objeto PRo e -->
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['PRO']->value, 'P');
$_smarty_tpl->tpl_vars['P']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['P']->value) {
$_smarty_tpl->tpl_vars['P']->do_else = false;
?>
      <li class="col-md-4">
        <div class="thumbnail">
          <a href="<?php echo $_smarty_tpl->tpl_vars['PRO_INFO']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_id'];?>
/<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_slug'];?>
">
            <img src="<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_img'];?>
" alt="">
            <div class="caption">
              <h4 class="text-center"><?php echo $_smarty_tpl->tpl_vars['P']->value['pro_nome'];?>
</h4>

              <h3 class="text-center text-danger"><?php echo $_smarty_tpl->tpl_vars['P']->value['pro_valor'];?>
</h3>
            </div>
          </a>
        </div>
      </li>
      <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
  </ul>

</section>

<!--paginação inferior-->
<section id="paginacao" class="row">
  <center>
      PAGINAS
  </center>
</section>
<?php }
}
