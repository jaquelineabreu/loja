<?php
/* Smarty version 3.1.36, created on 2020-12-23 12:45:39
  from 'C:\wamp64\www\loja\view\produtos_info.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5fe33bf32d70d4_62442202',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fcc81274c26651d7e7b7f161a32213380de98628' => 
    array (
      0 => 'C:\\wamp64\\www\\loja\\view\\produtos_info.tpl',
      1 => 1608727536,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fe33bf32d70d4_62442202 (Smarty_Internal_Template $_smarty_tpl) {
?>      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['PRO']->value, 'P');
$_smarty_tpl->tpl_vars['P']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['P']->value) {
$_smarty_tpl->tpl_vars['P']->do_else = false;
?>
      <h3 class="text-center"><?php echo $_smarty_tpl->tpl_vars['P']->value['pro_nome'];?>
 - Ref:<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_referencia'];?>
</h3>
      <hr>
      <div class="row">
                <div class="col-md-6">
            <img class="thumnail" src="<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_img'];?>
" alt="">
        </div>

                <div class="col-md-6">
            <img class="thumnail" src="" alt="">
        </div>
                <div class="col-md-6">
            <h3 class="text-center preco">R$ <?php echo $_smarty_tpl->tpl_vars['P']->value['pro_valor'];?>
</h3>
        </div>

                <div class="col-md-6">
          <form name="carrinho" method="post" action="">
            <input type="hidden" name="pro_id" value="<?php echo $_smarty_tpl->tpl_vars['P']->value['pro_id'];?>
">
            <input type="hidden" name="acao" value="add">
            <button class="btn btn-geral btn-lg">Comprar</button>
          </form>
        </div>
      </div>

      <div class="row">
        <hr>
        <h4 class="texte-center">Mais imagens</h4>
        <ul style="list-style:none">
          <li class="col-md-3">
            <img src="" alt="" class="thumbnail">
          </li>
        </ul>
      </div>

      <div class="row">
        <hr>
        <h4 class="texte-center">Descrição do Produto</h4>
        <br/>
        <p><?php echo $_smarty_tpl->tpl_vars['P']->value['pro_des'];?>
</p>
      </div>

      <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
