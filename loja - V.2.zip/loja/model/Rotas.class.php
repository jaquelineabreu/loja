<?php

	/*classe estatica consigo chamar mesmo sem instaciar a classe */
	Class Rotas{

		public static $pag;
		private static $pasta_controller = 'controller';
		private static $pasta_view = 'view/tema';


		//Captura a pasta home do site -  Pasta principal
		static function get_SiteHome(){
			return Config::SITE_URL . '/' .Config::SITE_FILE;

		}

		//pega a raiz
		static function get_SiteRaiz(){
			return $_SERVER['DOCUMENT_ROOT'] . '/' .Config::SITE_FILE;

		}

		//pega template
		static function get_SiteTema(){
			return  self::get_SiteHome(). '/' .self::$pasta_view;

		}

		static function pag_Carrinho(){
			return  self::get_SiteHome(). '/carrinho' ;
		}

		static function pag_Produtos(){
			return  self::get_SiteHome(). '/produtos' ;
		}

		static function pag_ProdutosInfo(){
			return  self::get_SiteHome(). '/produtos_info' ;
		}

		static function pag_Contato(){
			return  self::get_SiteHome(). '/contato' ;

		}

		static function pag_MinhaConta(){
			return  self::get_SiteHome(). '/minhaconta' ;

		}

		//upload da imagem
		static function get_ImagePasta(){
			return 'media/img/';
		}

		static function get_ImageURL(){
			return self::get_SiteHome() . '/' . self::get_ImagePasta();
		}

		static function ImageLink($img,$largura,$altura){
			$imagem =  self::get_ImageURL() . "thumb.php?src={$img}&w={$largura}&h={$altura}&zc=1";

			return $imagem;
		}




		static function get_pagina(){
			/*se foi chamado na url*/
			if(isset($_GET['pag'])){

				$pagina = $_GET['pag'];

				//mesma coisa que o this
				self::$pag = explode('/', $pagina);
				//var_dump(self::$pag);


				$pagina = 'controller/' .self::$pag[0] . '.php';
				//$pagina = 'controller/' .$_GET['pag'] . '.php';

				/*Verificar se existe*/
				if(file_exists($pagina)){
					include $pagina;
				}
				else{
				include 'erro.php';

				}

			}
		}
	}

?>
