<?php

$smarty = new Template();
$smarty->assign('CONTATO', 'Página de contato');
$smarty->display('contato.tpl');

?>

