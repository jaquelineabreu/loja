<?php

  $smarty = new template();

    //instaciar a classe produtos
  $produtos = new Produtos();
  $produtos->GetProdutosID(Rotas::$pag[1]);

  //var_dump($produtos->GetItens());
  $smarty->assign('PRO',$produtos->GetItens());

  $smarty->display('produtos_info.tpl');

  //var_dump($produtos->GetItens());



 ?>
