<?php

  $smarty = new template();

    //instaciar a classe produtos
  $produtos = new Produtos();
  $produtos->GetProdutos();

  //var_dump($produtos->GetItens());
  $smarty->assign('PRO',$produtos->GetItens());
  $smarty->assign('PRO_INFO',Rotas::pag_ProdutosInfo());
  $smarty->display('produtos.tpl');



 ?>
