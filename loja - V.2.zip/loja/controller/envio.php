<?php

	$to      = Config::EMAIL_USER;
	$subject = 'Contato - Loja Estudos';
	$message = 'Email de '. $_GET['txtname']. "\r\n" . $_GET['txtinputarea'];
	$dest = $_GET['txtemail'];

	$headers = "From: " . $dest;


	mail($to, $subject, $message, $headers);
?>

<script type="text/javascript">alert('Email enviado com sucesso!')</script>
<meta http-equiv="refresh" content="0; url=contato">
