<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'smarty/smarty' => 
    array (
      'pretty_version' => 'v3.1.36',
      'version' => '3.1.36.0',
      'aliases' => 
      array (
      ),
      'reference' => 'fd148f7ade295014fff77f89ee3d5b20d9d55451',
    ),
  ),
);
