<?php

	/*classe estatica consigo chamar mesmo sem instaciar a classe */
	Class Rotas{

		public static $pag;
		private static $pasta_controller = 'controller';
		private static $pasta_view = 'view/tema';


		//Captura a pasta home do site -  Pasta principal
		static function get_SiteHome(){
			return Config::SITE_URL . '/' .Config::SITE_FILE;

		}

		//pega a raiz
		static function get_SiteRaiz(){
			return $_SERVER['DOCUMENT_ROOT'] . '/' .Config::SITE_FILE;

		}

		//pega template
		static function get_SiteTema(){
			return  self::get_SiteHome(). '/' .self::$pasta_view;

		}

		static function pag_Carrinho(){
			return  self::get_SiteHome(). '/carrinho' ;

		}

		static function pag_Contato(){
			return  self::get_SiteHome(). '/contato' ;

		}

		static function pag_MinhaConta(){
			return  self::get_SiteHome(). '/minhaconta' ;

		}





		static function get_pagina(){
			/*se foi chamado na url*/
			if(isset($_GET['pag'])){

				$pagina = $_GET['pag'];

				//mesma coisa que o this
				self::$pag = explode('/', $pagina);
				//var_dump(self::$pag);


				$pagina = 'controller/' .self::$pag[0] . '.php';
				//$pagina = 'controller/' .$_GET['pag'] . '.php';
				
				/*Verificar se existe*/
				if(file_exists($pagina)){
					include $pagina;
				}
				else{
				include 'erro.php';

				}
			
			}
		}
	}

?>