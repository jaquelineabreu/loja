<?php

	Class Produtos extends Conexao{

		function __construct(){
			parent::__construct();

		}


		//query para buscar os produtos de uma categoria especifica
		function GetProdutos(){
			$query = "select * from {$this->prefix}produtos p
			INNER JOIN {$this->prefix}categorias c ON p.pro_categoria = c.cate_id";
		}

	}


?>