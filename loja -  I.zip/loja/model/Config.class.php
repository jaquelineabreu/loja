<?php



		Class Config{

		//Informações Básicas do Site
		const SITE_URL = "http://localhost";
		const SITE_FILE = "loja";
		const SITE_NOME = "Loja de Estudos - PHP 7 e Mysqli";
		const SITE_EMAIL_ADM = "webestudosgit@gmail.com";





		//Informações do Bando de Dados
		const BD_HOST = "localhost",
			  BD_USER = "root",
			  BD_SENHA = "",
			  BD_BANCO = "loja_",
			  BD_PREFIX = "";			

		//Informações PHP MAILLER
		const EMAIL_HOST = "smtp.gmail.com";
		const EMAIL_USER = "webestudosgit@gmail.com";
		const EMAIL_NOME = "Contato Loja Estudos";
		const EMAIL_SENHA = "";
		const EMAIL_PORTA = 587;
		const EMAIL_SMTPAUTH = true;
		const EMAIL_SMTPSECURE = "tls";
		const EMAIL_COPIA = "webestudosgit@gmail.com";

	




		}

?>
